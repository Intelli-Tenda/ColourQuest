# ColourQuest – Mobile Upload Package
If you can only upload a single file from your phone, use this.

## Steps
1. Create a new **public** repo named `ColourQuest` on GitHub.
2. Upload **this** ZIP to the repo root.
3. Go to the **Actions** tab → run **Build ColourQuest APK (ZIP upload)**.
4. Download your APK from **Artifacts** when the run finishes.

The workflow unzips `ColourQuestProject.zip` into `ColourQuest/` and builds the app.
